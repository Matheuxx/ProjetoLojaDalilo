﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Linq;

namespace Lolja
{
    public partial class Form2 : Form
    {
        double Total, Headset, Mouse, Teclado, Card = 0;
        public Form2()
        {
            InitializeComponent();
        }


        private void ChckFone_CheckedChanged(object sender, EventArgs e)
        {
            if (chckFone.Checked)
            {
                Headset = 200.00;
                btnComprar.Visible = true;
                lblTotal.Visible = true;
                Total = Headset + Mouse + Teclado + Card;
                lblTotal.Text = "Total: R$ " + Math.Round(Total, 2).ToString();
            }
            if (chckFone.Checked == false)
            {
                Headset = 0;
                Total = Headset + Mouse + Teclado + Card;
                lblTotal.Text = "Total: R$ " + Math.Round(Total, 2).ToString();

            }
        }

        private void ChckMouse_CheckedChanged(object sender, EventArgs e)
        {
            if (chckMouse.Checked)
            {
                Mouse = 247.90;
                btnComprar.Visible = true;
                lblTotal.Visible = true;
                Total = Headset + Mouse + Teclado + Card;
                lblTotal.Text = "Total: R$ " + Math.Round(Total,2).ToString();
            }
            if(chckMouse.Checked == false)
            {
                Mouse = 0;
                Total = Headset + Mouse + Teclado + Card ;
                lblTotal.Text = "Total: R$ " + Math.Round(Total, 2).ToString();
            }
        }

        private void ChckTeclado_CheckedChanged(object sender, EventArgs e)
        {
            if (chckTeclado.Checked)
            {
                Teclado = 350.90;
                btnComprar.Visible = true;
                lblTotal.Visible = true;
                Total = Headset + Mouse + Teclado + Card;
                lblTotal.Text = "Total: R$ " + Math.Round(Total, 2).ToString();
            }
            if (chckTeclado.Checked == false)
            {
                Teclado = 0;
                Total = Headset + Mouse + Teclado + Card;
                lblTotal.Text = "Total: R$ " + Math.Round(Total, 2).ToString();
            }
        }

        private void ChckCard_CheckedChanged(object sender, EventArgs e)
        {
            if (chckCard.Checked)
            {
                Card = 50.00;
                lblTotal.Visible = true;
                btnComprar.Visible = true;
                Total = Headset + Mouse + Teclado + Card;
                lblTotal.Text = "Total: R$ " + Math.Round(Total, 2).ToString();
            }
            if (chckCard.Checked == false)
            {
                Card = 0;
                Total = Headset + Mouse + Teclado + Card;
                lblTotal.Text = "Total: R$ " + Math.Round(Total, 2).ToString();
                
            }
        }

        private void BtnComprar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Você será redirecionado para a página de finalização de compra. Obrigado por comprar conosco!","Alerta de Compra");
            this.Close();
        }

        private void BtnFone_Click(object sender, EventArgs e)
        {
            lblFone.Text = "Headset HyperX Stinger - R$ 200.00";
            chckFone.Visible = true;
        }

        private void BtnMouse_Click(object sender, EventArgs e)
        {
            lblMouse.Text = "Mouse HyperX Pulsefire Surge - R# 247,90";
            chckMouse.Visible = true;
        }

        private void BtnTeclado_Click(object sender, EventArgs e)
        {
            lblTeclado.Text = "Teclado Mecanico HyperX Mars -  R$ 350,00";
            chckTeclado.Visible = true;
            
        }

        private void BtnCard_Click(object sender, EventArgs e)
        {
            lblCard.Text = "Cartão pré-pago Spotify 3 meses - R$ 50,00";
            chckCard.Visible = true;
        }
    }
}
