﻿namespace Lolja
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFone = new System.Windows.Forms.Label();
            this.lblTeclado = new System.Windows.Forms.Label();
            this.lblMouse = new System.Windows.Forms.Label();
            this.lblCard = new System.Windows.Forms.Label();
            this.btnCard = new System.Windows.Forms.Button();
            this.btnMouse = new System.Windows.Forms.Button();
            this.btnTeclado = new System.Windows.Forms.Button();
            this.btnFone = new System.Windows.Forms.Button();
            this.chckFone = new System.Windows.Forms.CheckBox();
            this.chckTeclado = new System.Windows.Forms.CheckBox();
            this.chckCard = new System.Windows.Forms.CheckBox();
            this.chckMouse = new System.Windows.Forms.CheckBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnComprar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblFone
            // 
            this.lblFone.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFone.Location = new System.Drawing.Point(9, 155);
            this.lblFone.Name = "lblFone";
            this.lblFone.Size = new System.Drawing.Size(86, 98);
            this.lblFone.TabIndex = 1;
            // 
            // lblTeclado
            // 
            this.lblTeclado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTeclado.Location = new System.Drawing.Point(213, 137);
            this.lblTeclado.Name = "lblTeclado";
            this.lblTeclado.Size = new System.Drawing.Size(86, 116);
            this.lblTeclado.TabIndex = 5;
            // 
            // lblMouse
            // 
            this.lblMouse.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMouse.Location = new System.Drawing.Point(438, 146);
            this.lblMouse.Name = "lblMouse";
            this.lblMouse.Size = new System.Drawing.Size(65, 107);
            this.lblMouse.TabIndex = 6;
            // 
            // lblCard
            // 
            this.lblCard.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCard.Location = new System.Drawing.Point(665, 155);
            this.lblCard.Name = "lblCard";
            this.lblCard.Size = new System.Drawing.Size(83, 98);
            this.lblCard.TabIndex = 7;
            this.lblCard.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCard
            // 
            this.btnCard.BackgroundImage = global::Lolja.Properties.Resources.Spotify;
            this.btnCard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCard.Location = new System.Drawing.Point(668, 35);
            this.btnCard.Name = "btnCard";
            this.btnCard.Size = new System.Drawing.Size(83, 97);
            this.btnCard.TabIndex = 4;
            this.btnCard.UseVisualStyleBackColor = true;
            this.btnCard.Click += new System.EventHandler(this.BtnCard_Click);
            // 
            // btnMouse
            // 
            this.btnMouse.BackgroundImage = global::Lolja.Properties.Resources.mouse;
            this.btnMouse.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMouse.Location = new System.Drawing.Point(441, 38);
            this.btnMouse.Name = "btnMouse";
            this.btnMouse.Size = new System.Drawing.Size(62, 91);
            this.btnMouse.TabIndex = 3;
            this.btnMouse.UseVisualStyleBackColor = true;
            this.btnMouse.Click += new System.EventHandler(this.BtnMouse_Click);
            // 
            // btnTeclado
            // 
            this.btnTeclado.BackgroundImage = global::Lolja.Properties.Resources.teclado;
            this.btnTeclado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTeclado.Location = new System.Drawing.Point(216, 32);
            this.btnTeclado.Name = "btnTeclado";
            this.btnTeclado.Size = new System.Drawing.Size(83, 91);
            this.btnTeclado.TabIndex = 2;
            this.btnTeclado.UseVisualStyleBackColor = true;
            this.btnTeclado.Click += new System.EventHandler(this.BtnTeclado_Click);
            // 
            // btnFone
            // 
            this.btnFone.BackgroundImage = global::Lolja.Properties.Resources.hyperx;
            this.btnFone.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnFone.Location = new System.Drawing.Point(12, 32);
            this.btnFone.Name = "btnFone";
            this.btnFone.Size = new System.Drawing.Size(83, 91);
            this.btnFone.TabIndex = 0;
            this.btnFone.UseVisualStyleBackColor = true;
            this.btnFone.Click += new System.EventHandler(this.BtnFone_Click);
            // 
            // chckFone
            // 
            this.chckFone.AutoSize = true;
            this.chckFone.Location = new System.Drawing.Point(12, 273);
            this.chckFone.Name = "chckFone";
            this.chckFone.Size = new System.Drawing.Size(113, 17);
            this.chckFone.TabIndex = 8;
            this.chckFone.Text = "Colocar na Sacola";
            this.chckFone.UseVisualStyleBackColor = true;
            this.chckFone.Visible = false;
            this.chckFone.CheckedChanged += new System.EventHandler(this.ChckFone_CheckedChanged);
            // 
            // chckTeclado
            // 
            this.chckTeclado.AutoSize = true;
            this.chckTeclado.Location = new System.Drawing.Point(216, 273);
            this.chckTeclado.Name = "chckTeclado";
            this.chckTeclado.Size = new System.Drawing.Size(113, 17);
            this.chckTeclado.TabIndex = 9;
            this.chckTeclado.Text = "Colocar na Sacola";
            this.chckTeclado.UseVisualStyleBackColor = true;
            this.chckTeclado.Visible = false;
            this.chckTeclado.CheckedChanged += new System.EventHandler(this.ChckTeclado_CheckedChanged);
            // 
            // chckCard
            // 
            this.chckCard.AutoSize = true;
            this.chckCard.Location = new System.Drawing.Point(668, 273);
            this.chckCard.Name = "chckCard";
            this.chckCard.Size = new System.Drawing.Size(113, 17);
            this.chckCard.TabIndex = 10;
            this.chckCard.Text = "Colocar na Sacola";
            this.chckCard.UseVisualStyleBackColor = true;
            this.chckCard.Visible = false;
            this.chckCard.CheckedChanged += new System.EventHandler(this.ChckCard_CheckedChanged);
            // 
            // chckMouse
            // 
            this.chckMouse.AutoSize = true;
            this.chckMouse.Location = new System.Drawing.Point(441, 273);
            this.chckMouse.Name = "chckMouse";
            this.chckMouse.Size = new System.Drawing.Size(113, 17);
            this.chckMouse.TabIndex = 11;
            this.chckMouse.Text = "Colocar na Sacola";
            this.chckMouse.UseVisualStyleBackColor = true;
            this.chckMouse.Visible = false;
            this.chckMouse.CheckedChanged += new System.EventHandler(this.ChckMouse_CheckedChanged);
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Location = new System.Drawing.Point(305, 380);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(0, 13);
            this.lblTotal.TabIndex = 12;
            this.lblTotal.Visible = false;
            // 
            // btnComprar
            // 
            this.btnComprar.Location = new System.Drawing.Point(337, 415);
            this.btnComprar.Name = "btnComprar";
            this.btnComprar.Size = new System.Drawing.Size(75, 23);
            this.btnComprar.TabIndex = 13;
            this.btnComprar.Text = "Comprar";
            this.btnComprar.UseVisualStyleBackColor = true;
            this.btnComprar.Visible = false;
            this.btnComprar.Click += new System.EventHandler(this.BtnComprar_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnComprar);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.chckMouse);
            this.Controls.Add(this.chckCard);
            this.Controls.Add(this.chckTeclado);
            this.Controls.Add(this.chckFone);
            this.Controls.Add(this.lblCard);
            this.Controls.Add(this.lblMouse);
            this.Controls.Add(this.lblTeclado);
            this.Controls.Add(this.btnCard);
            this.Controls.Add(this.btnMouse);
            this.Controls.Add(this.btnTeclado);
            this.Controls.Add(this.lblFone);
            this.Controls.Add(this.btnFone);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFone;
        private System.Windows.Forms.Label lblFone;
        private System.Windows.Forms.Button btnTeclado;
        private System.Windows.Forms.Button btnMouse;
        private System.Windows.Forms.Button btnCard;
        private System.Windows.Forms.Label lblTeclado;
        private System.Windows.Forms.Label lblMouse;
        private System.Windows.Forms.Label lblCard;
        private System.Windows.Forms.CheckBox chckFone;
        private System.Windows.Forms.CheckBox chckTeclado;
        private System.Windows.Forms.CheckBox chckCard;
        private System.Windows.Forms.CheckBox chckMouse;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnComprar;
    }
}